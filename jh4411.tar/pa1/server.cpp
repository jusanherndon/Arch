#include <iostream>
#include <fstream>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <time.h>
#include <string.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

using namespace std;

int main(int argc, char *argv[]){

	struct sockaddr_in server;
	struct sockaddr_in server1;
	struct sockaddr_in client;
	struct sockaddr_in client1;
	int r_port;
	std::ofstream myfile;
	std::string myline;
	char r_port_char[64];
	int mysocket = 0;
	int mysocket1 = 0;
	socklen_t clen = sizeof(client);
	socklen_t clen1 = sizeof(client1);
	char payload[6];
	char message[512];

	if((mysocket= socket(AF_INET, SOCK_DGRAM, 0)) ==-1 ){
		cout << "Error in socket creation.\n";
	}
	memset((char *) &server, 0, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_port = htons(std::atoi(argv[1]));
	server.sin_addr.s_addr = htons(INADDR_ANY);
	if(bind(mysocket, (struct sockaddr *)&server, sizeof(server)) ==-1){
		cout << "Error in binding.\n";
	}
	// logic for handshake
		
	r_port = rand()%64511 + 1024;
	
	cout << "Random port chosen: " << r_port << std::endl;

	sprintf(r_port_char, "%d", r_port);
	
	while(recvfrom(mysocket,message, 512, 0, (struct sockaddr *)&client, &clen)== -1){
			cout << "Failed to receive.\n";
	}

	if(sendto(mysocket, r_port_char, 64, 0, (struct sockaddr *)&client, clen) == -1){
		cout << "Error in sendto function.\n";
	}
	close(mysocket);
	// close handshake

	if((mysocket1= socket(AF_INET, SOCK_DGRAM, 0)) ==-1 ){
		cout << "Error in socket creation.\n";
	}
	memset((char *) &server1, 0, sizeof(server1));
	server1.sin_family = AF_INET;
	server1.sin_port = htons(r_port);
	server1.sin_addr.s_addr = htons(INADDR_ANY);
	if(bind(mysocket1, (struct sockaddr *)&server1, sizeof(server1)) ==-1){
		cout << "Error in binding.\n";
	}

	myfile.open("upload.txt");	

	memset(payload,0,6);
	while(1){
		if(recvfrom(mysocket1,payload, 6, 0, (struct sockaddr *)&client1, &clen1)== -1){
			cout << "Failed to receive.\n";
		}
		
		if(payload[5] == 1){
			break;
		}
		if(payload[5] == 0){
			myfile << payload;
		}
	}
	
	myfile.close();

	char ack[] = "Got all that data, thanks";

	if(sendto(mysocket1, ack, 20, 0, (struct sockaddr *)&client1, clen1) == -1){
		cout << "Error in sendto function.\n";
	}

	close(mysocket1);
	return 0;
}
