#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fstream>
#include <arpa/inet.h>
#include <string.h>
#include <cstring>
#include <unistd.h>

int main(int argc, char *argv[]){

	std::ifstream myfile; 
	int counter = 0;
	char payload[6];
	char message[] = "1248";
	struct hostent *s;
	struct hostent *s1;
	struct sockaddr_in server;
	struct sockaddr_in server1;
	struct in_addr a;
	struct in_addr a1;

	s = gethostbyname(argv[2]);

	int mysocket = 0;
	int mysocket1 = 0;
	socklen_t slen = sizeof(server);
	socklen_t slen1 = sizeof(server1);

	if((mysocket= socket(AF_INET, SOCK_DGRAM, 0)) == -1){
		std::cout << "Error in creating socket\n";
	}
	memset((char *) &server, 0, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_port = htons(std::atoi(argv[1]));
	bcopy((char *)s->h_addr, (char *)&server.sin_addr.s_addr, s->h_length);
	
	printf("name: %s\n", s->h_name);
	
	while(*s->h_aliases){
		printf("alias: %s",*s->h_aliases++);
	}
	while(*s->h_addr_list){
		bcopy(*s->h_addr_list++, (char *) &a, sizeof(a));
		printf("address: %s\n", inet_ntoa(a));
	}

// Add in logic to switch ports after handshake
	if(sendto(mysocket,message,512,0, (struct sockaddr *)&server,slen)==-1){
			std::cout << "Error in sendto function.\n";
		}

	char port_char[512];
	int port; 

	recvfrom(mysocket, port_char, 512,0, (struct sockaddr *)&server, &slen);
	close(mysocket);

	port = std::atoi(port_char); 

	// stop handshake
	
	s1 = gethostbyname(argv[2]);

	memset((char *) &server1, 0, sizeof(server1));
	server1.sin_family = AF_INET;
	server1.sin_port = htons(port);
	bcopy((char *)s1->h_addr, (char *)&server1.sin_addr.s_addr, s1->h_length);

	if((mysocket1= socket(AF_INET, SOCK_DGRAM, 0)) == -1){
		std::cout << "Error in creating socket\n";
	}
	
	while(*s1->h_aliases){
		printf("alias: %s",*s1->h_aliases++);
	}
	while(*s1->h_addr_list){
		bcopy(*s1->h_addr_list++, (char *) &a1, sizeof(a1));
		printf("address: %s\n", inet_ntoa(a1));
	}

	
	memset(payload,0,6);
// Logic that handles getting lines from file and creating a payload
	myfile.open(argv[3]);


	while(1){
		
		myfile.read(payload,4); 
		payload[5]= 0;
		payload[6]= 0;

		std::cout << "Payload contains: " << payload << std::endl;
		
		if(myfile.eof() == 1) {
			break;
		}

		if(sendto(mysocket1,payload,6,0, (struct sockaddr *)&server1,slen1)==-1){
			std::cout << "Error in sendto function.\n";
		}
		
		counter += 1;
	}

	char finish[6];
	
	memset(finish,0,6);

	finish[5] = 1;
	
	if(sendto(mysocket1,finish,6,0, (struct sockaddr *)&server1,slen1)==-1){
			std::cout << "Error in sendto function.\n";
		}

	myfile.close();

	char ack[10];

	recvfrom(mysocket1, ack, 10,0, (struct sockaddr *)&server1, &slen1);
	close(mysocket1);
	return 0;
}
