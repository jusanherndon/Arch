// Author: Maxwell Young
// Created for Fall 2021 Data Comm. for helping a student with serialization
// Updated on Mar. 21, 2022

// To test this code, you need two shells open on Pluto
// run ./server
// run ./client localhost


#include <stdlib.h>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <sys/types.h>   // defines types (like size_t)
#include <sys/socket.h>  // defines socket class
#include <netinet/in.h>  // defines port numbers for (internet) sockets, some address structures, and constants
#include <netdb.h> 
#include <iostream>
#include <fstream>
#include <arpa/inet.h>   // if you want to use inet_addr() function
#include <string.h>
#include <unistd.h>
#include "packet.h" // include packet class
#include <math.h>
#include "client.h"

using namespace std;

#define payLen 30
#define packetLen 50


client::client(char * filename, char * seqlog, char * acklog){

	// file input/output
	ofileSeq = new ofstream(seqlog);
	ofileAck = new ofstream(acklog);
    myIStream = new ifstream(filename);

}

// send the next segment	
int client::sendData(int seqNumber, int socket, sockaddr_in & saddr){	// socket should be CEsocket
	char spacket[packetLen];   // for serializing the packet to send	
	char payload[payLen+1] = "123456789";    // my packet that contains text
	
	packet mySendPacket(1, seqNumber, strlen(payload), payload); // make the packet to be sent
	mySendPacket.printContents();
		
	memset(spacket, 0, packetLen); // serialize the packet to be sent
	mySendPacket.serialize(spacket);
		
	if(sendto(socket, spacket, sizeof(spacket), 0, (struct sockaddr *)&saddr, sizeof(saddr)) < 0){
			cout << "Failed to send payload.\n";
			return 0;
	}
	return 1;
}	

int main(int argc, char *argv[]){

	// declare and setup server
	struct hostent *em_host;            // pointer to a structure of type hostent
	em_host = gethostbyname(argv[1]);   // host name for emulator
	if(em_host == NULL){                // failed to obtain server's name
		cout << "Failed to obtain server.\n";
		exit(EXIT_FAILURE);
	}
 
  // ******************************************************************
  // ******************************************************************

  // client sets up datagram socket for sending
  int CESocket = socket(AF_INET, SOCK_DGRAM, 0);  
  if(CESocket < 0){
  	cout << "Error: failed to open datagram socket.\n";
  }

  // set up the sockaddr_in structure for sending
  struct sockaddr_in CE; 
  socklen_t CE_length = sizeof(CE);
  bzero(&CE, sizeof(CE)); 
  CE.sin_family = AF_INET;	
  bcopy((char *)em_host->h_addr, (char*)&CE.sin_addr.s_addr, em_host->h_length);  // both using localhost so this is fine
  char * end;
  int em_rec_port = strtol(argv[2], &end, 10);  // get emulator's receiving port and convert to int
  CE.sin_port = htons(em_rec_port);             // set to emulator's receiving port

  // ******************************************************************
  // ******************************************************************

  // client sets up datagram socket for receiving
  int ECSocket = socket(AF_INET, SOCK_DGRAM, 0);  
  if(ECSocket < 0){
  	cout << "Error: failed to open datagram socket.\n";
  }

  // set up the sockaddr_in structure for receiving
  struct sockaddr_in EC; 
  socklen_t EC_length = sizeof(EC);
  bzero(&EC, sizeof(EC)); 
  EC.sin_family = AF_INET;	
  EC.sin_addr.s_addr = htonl(INADDR_ANY);	
  char * end2;
  int cl_rec_port = strtol(argv[3], &end2, 10);  // client's receiving port and convert to int
  EC.sin_port = htons(cl_rec_port);             // set to emulator's receiving port

  // do the binding
  if (bind(ECSocket, (struct sockaddr *)&EC, EC_length) == -1){
  		cout << "Error in binding.\n";
  } 
 
  // ******************************************************************
  // ******************************************************************  
 
  char slog[] = "seqnum.log"; 
  char alog[] = "ack.log";	   
  client myClient(argv[4], slog, alog);	  
  for(int i=0; i<3; i++){
	  myClient.sendData(0, CESocket, CE);	  
  }
	  
  // This is where I handle getting back an ACK from the server	  
  char serialized[512];
  memset(serialized, 0, 512); 	  
  recvfrom(ECSocket, serialized, 512, 0, (struct sockaddr *)&EC, &EC_length);	  
  cout << "Received packet and deserialized to obtain the following: " << endl << endl;
  
  char ackload[512];
  memset(ackload, 0, 512);
  packet rcvdPacket(0,0,0,ackload);
  rcvdPacket.deserialize(serialized);	
  rcvdPacket.printContents();	  
    
  close(CESocket);
  return 0;
}
